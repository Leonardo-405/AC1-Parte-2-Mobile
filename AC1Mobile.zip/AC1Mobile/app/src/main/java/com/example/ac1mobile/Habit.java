package com.example.ac1mobile;

public class Habit {
    private String name;
    private String description;
    private boolean completedToday;

    public Habit(String name, String description) {
        this.name = name;
        this.description = description;
        this.completedToday = false;
    }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    public boolean isCompletedToday() { return completedToday; }
    public void setCompletedToday(boolean completedToday) { this.completedToday = completedToday; }
}



