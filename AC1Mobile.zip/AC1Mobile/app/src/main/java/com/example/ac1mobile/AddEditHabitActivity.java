package com.example.ac1mobile;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class AddEditHabitActivity extends Activity {

    private EditText habitNameEditText;
    private EditText habitDescriptionEditText;
    private int positionToEdit = -1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_edit_habit);

        habitNameEditText = findViewById(R.id.habitNameEditText);
        habitDescriptionEditText = findViewById(R.id.habitDescriptionEditText);

        Intent intent = getIntent();
        String habitName = intent.getStringExtra("habitName");
        String habitDescription = intent.getStringExtra("habitDescription");

        if (habitName != null && habitDescription != null) {
            habitNameEditText.setText(habitName);
            habitDescriptionEditText.setText(habitDescription);
            positionToEdit = intent.getIntExtra("position", -1);
        }

        findViewById(R.id.saveButton).setOnClickListener(v -> {
            String name = habitNameEditText.getText().toString().trim();
            String description = habitDescriptionEditText.getText().toString().trim();

            if (!name.isEmpty()) {
                Intent resultIntent = new Intent();
                resultIntent.putExtra("habitName", name);
                resultIntent.putExtra("habitDescription", description);
                if (positionToEdit != -1) {
                    resultIntent.putExtra("position", positionToEdit);
                }
                setResult(RESULT_OK, resultIntent);
                finish();
            } else {
                Toast.makeText(this, getString(R.string.enter_habit_name), Toast.LENGTH_SHORT).show();
            }
        });

        findViewById(R.id.cancelButton).setOnClickListener(v -> {
            setResult(RESULT_CANCELED);
            finish();
        });
    }
}



