package com.example.ac1mobile;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends Activity {

    private RecyclerView recyclerView;
    private HabitAdapter habitAdapter;
    private List<Habit> habitList = new ArrayList<>();
    private static final int REQUEST_EDIT_HABIT = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        habitAdapter = new HabitAdapter(habitList);
        recyclerView.setAdapter(habitAdapter);

        habitList.add(new Habit(getString(R.string.sample_habit1), getString(R.string.sample_desc1)));
        habitList.add(new Habit(getString(R.string.sample_habit2), getString(R.string.sample_desc2)));

        habitAdapter.notifyDataSetChanged();

        habitAdapter.setOnItemLongClickListener(position -> {
            habitList.remove(position);
            habitAdapter.notifyItemRemoved(position);
            Toast.makeText(this, getString(R.string.habit_deleted), Toast.LENGTH_SHORT).show();
        });

        habitAdapter.setOnItemClickListener(position -> {
            Habit habit = habitList.get(position);
            Intent intent = new Intent(this, AddEditHabitActivity.class);
            intent.putExtra("habitName", habit.getName());
            intent.putExtra("habitDescription", habit.getDescription());
            intent.putExtra("position", position);
            startActivityForResult(intent, REQUEST_EDIT_HABIT);
        });

        findViewById(R.id.addButton).setOnClickListener(v -> {
            Intent intent = new Intent(this, AddEditHabitActivity.class);
            startActivityForResult(intent, 0);
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK && data != null) {
            String habitName = data.getStringExtra("habitName");
            String habitDescription = data.getStringExtra("habitDescription");

            if (requestCode == 0) {
                Habit newHabit = new Habit(habitName, habitDescription);
                habitList.add(newHabit);
                habitAdapter.notifyItemInserted(habitList.size() - 1);
            } else if (requestCode == REQUEST_EDIT_HABIT) {
                int position = data.getIntExtra("position", -1);
                if (position != -1) {
                    Habit habit = habitList.get(position);
                    habit.setName(habitName);
                    habit.setDescription(habitDescription);
                    habitAdapter.notifyItemChanged(position);
                }
            }
        }
    }
}



